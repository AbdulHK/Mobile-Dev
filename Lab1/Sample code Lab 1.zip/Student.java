/*                
 * 
 *   Lab 1: Studenet class
 *   Author: Susan McKeever
 *   Sept 2015
 */
package com.msd.lab1;

public class Student extends Person implements PublishDetails
{

	  // instance variables
	  private int studentId;
			
	  // constructor to set up Student 
	  public Student(String name, char gender, int studentId)
	  {
	 	super(name, gender);
		this.studentId = studentId;
	  }
			
	   // toString method
	   public String toString()
	   {
	   	String strng = super.toString();	// use toString from Person
		strng+= " with student number "+studentId;
		return strng;
	   }
	
	   public void confirmDetails()
	   {
		  // whatever I want to put in	
	   }
		
	   public String getCourseCode()
	   {
		   String courseCode = "My course code etc ";	
		   return courseCode;
	   }
	   
} // end class


