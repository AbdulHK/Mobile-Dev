/*                
 * 
 *   Lab 1: sample interface
 *   Author: Susan McKeever
 *   Sept 2015
 */

package com.msd.lab1;

public interface PublishDetails 
{
	
		void confirmDetails();
		String getCourseCode();

	
}
