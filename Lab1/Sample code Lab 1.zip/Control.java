/*                
 * 
 *   Lab 1: Control Class
 *   Author: Susan McKeever
 *   Sept 2015
 */

package com.msd.lab1;

public class Control 
{

	public static void main(String[] args) 
	{

		// instantiate a person and print out details of the 			object
		Person p = new Person ("Joe",'m' );
		System.out.println(p);
	
		// instantiate students 
		/*Student student1 = new Student("Mary", 'f', 23432);
		System.out.println(student1);

		Student student2 = new Student("Sean", 'm', 88734);
		System.out.println(student2);*/

	
	} // end main

} // end class

