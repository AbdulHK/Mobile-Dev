**********************************************
*
*
*   Always include your comment header...
*   Plus comments in your code...
*
**********************************************
// package statement...

// import statements if required..


public class Circle extends Shape 
{

	public double radius;
	public static final double PI = 3.14;	

	public Circle (double radius) 
	{
		this.radius = radius;
	}
	

	public double area() 
 	{
		double a = PI * radius * radius;
		return a;		
	}

	public String toString() 
	{

		String s = "Shape Type = "+getClass()+" Area = "+area();
		return s;
	}

} 
