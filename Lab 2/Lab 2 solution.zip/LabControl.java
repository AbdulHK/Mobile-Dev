**********************************************
*
*
*   Always include your comment header...
*   Plus comments in your code...
*
**********************************************
// package statement...

// import statements if required..

public class LabControl {

	public static void main (String [] args) {

		Shape[] myShapes = new Shape[4];
		myShapes[0] = new Circle(13);
		myShapes[1] = new Circle(15);
		myShapes[2] = new Square(20);
		myShapes[3] = new ThreeDCircle(15);

		for (int i=0;i<4;i++) {
			System.out.println(myShapes[i]);

		}

	}

}
