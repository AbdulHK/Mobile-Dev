**********************************************
*
*
*   Always include your comment header...
*   Plus comments in your code...
*
**********************************************
// package statement...

// import statements if required..


public class Square extends Shape 
{

	public double length;


    // This is the constructor method
	public Square (double length)
     {

		this.length = length;

	}

	// This is the implementation of the abstract method
	public double area() 
	{
		double a = length * length;
		return a;
	}

	// This is our own version of the toSting method which we have overwritten
	public String toString() 
	{

		String s = "Shape Type = "+getClass()+" Area = "+area();
		return s;
	}

}
