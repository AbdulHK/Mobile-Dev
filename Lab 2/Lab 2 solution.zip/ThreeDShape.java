**********************************************
*
*
*   Always include your comment header...
*   Plus comments in your code...
*
**********************************************
// package statement...

// import statements if required..


public interface ThreeDShape 
{

	public double volume();
}
