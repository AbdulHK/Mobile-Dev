**********************************************
*
*
*   Always include your comment header...
*   Plus comments in your code...
*
**********************************************
// package statement...

// import statements if required..


public class ThreeDCircle extends Circle implements ThreeDShape
{
	
	public double volume;

	public ThreeDCircle (double radius) 
	{
		super(radius);
		
	}
	
	public double volume() 
	{
		volume = 4/3*PI*radius*radius*radius;
		return volume;
	}
	public double area() 
	{
		double a = 4*PI * radius * radius;
		return a;		
	}

	public String toString() 
	{

		String s = super.toString();
		s += " And Volume = "+ volume();
		return s;
	}

}
